from django.urls import path
from . import views

urlpatterns = [
    # Static Pages
    path('', views.home, name='home'),
    path('about/', views.about, name='about'),
    path('contact/', views.contact, name='contact'),

    # Auth
    path('signup/', views.signup_view, name='signup'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('profile/', views.profile, name='profile'),
    path('profile/edit/', views.edit_profile, name='edit_profile'),

    # Hackathon CRUD
    path('hackathons/', views.hackathon_list, name='hackathon_list'),
    path('hackathons/new/', views.hackathon_create, name='hackathon_create'),
    path('hackathons/<int:pk>/', views.hackathon_detail, name='hackathon_detail'),
    path('hackathons/<int:pk>/edit/', views.hackathon_edit, name='hackathon_edit'),
    path('hackathons/<int:pk>/delete/', views.hackathon_delete, name='hackathon_delete'),

    # Team Registration
    path('hackathons/<int:pk>/register/', views.register_team, name='register_team'),
]
