from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib import messages

from .models import Hackathon, Registration

# ----------------- Static Pages -------------------

def home(request):
    return render(request, 'core/home.html')

def about(request):
    return render(request, 'core/about.html')

def contact(request):
    return render(request, 'core/contact.html')

# ----------------- Auth Views ---------------------

def signup_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        if User.objects.filter(username=username).exists():
            messages.error(request, 'Username already taken.')
            return redirect('signup')
        user = User.objects.create_user(username=username, email=email, password=password)
        login(request, user)
        return redirect('home')
    return render(request, 'core/signup.html')

def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            return redirect('home')
        else:
            messages.error(request, 'Invalid credentials')
            return redirect('login')
    return render(request, 'core/login.html')

@login_required
def logout_view(request):
    logout(request)
    return redirect('login')

@login_required
def edit_profile(request):
    if request.method == 'POST':
        user = request.user
        user.username = request.POST['username']
        user.email = request.POST['email']
        if request.POST['password']:
            user.set_password(request.POST['password'])
        user.save()
        messages.success(request, 'Profile updated.')
        return redirect('edit_profile')
    return render(request, 'core/edit_profile.html')

# ---------------- Hackathon CRUD -------------------

def hackathon_list(request):
    hackathons = Hackathon.objects.all().order_by('-created_at')
    return render(request, 'core/hackathon_list.html', {'hackathons': hackathons})

@login_required
def hackathon_create(request):
    if request.method == 'POST':
        title = request.POST['title']
        description = request.POST['description']
        start_date = request.POST['start_date']
        end_date = request.POST['end_date']
        image = request.FILES.get('image')

        Hackathon.objects.create(
            host=request.user,
            title=title,
            description=description,
            start_date=start_date,
            end_date=end_date,
            image=image
        )
        return redirect('hackathon_list')
    return render(request, 'core/hackathon_create.html')

def hackathon_detail(request, pk):
    hackathon = get_object_or_404(Hackathon, pk=pk)
    return render(request, 'core/hackathon_detail.html', {'hackathon': hackathon})

@login_required
def hackathon_edit(request, pk):
    hackathon = get_object_or_404(Hackathon, pk=pk, host=request.user)
    if request.method == 'POST':
        hackathon.title = request.POST['title']
        hackathon.description = request.POST['description']
        hackathon.start_date = request.POST['start_date']
        hackathon.end_date = request.POST['end_date']
        hackathon.save()
        return redirect('hackathon_detail', pk=pk)
    return render(request, 'core/hackathon_edit.html', {'hackathon': hackathon})

@login_required
def hackathon_delete(request, pk):
    hackathon = get_object_or_404(Hackathon, pk=pk, host=request.user)
    if request.method == 'POST':
        hackathon.delete()
        return redirect('hackathon_list')
    return render(request, 'core/hackathon_delete.html', {'hackathon': hackathon})

# ---------------- Register for Hackathon -------------------

@login_required
def register_team(request, pk):
    hackathon = get_object_or_404(Hackathon, pk=pk)

    if request.method == 'POST':
        team_name = request.POST['team_name']
        github_link = request.POST['github_link']

        if Registration.objects.filter(hackathon=hackathon, participant=request.user).exists():
            messages.error(request, 'You have already registered for this hackathon.')
        else:
            Registration.objects.create(
                hackathon=hackathon,
                participant=request.user,
                team_name=team_name,
                github_link=github_link
            )
            messages.success(request, 'Successfully registered for the hackathon!')
            return redirect('hackathon_detail', pk=pk)

    return render(request, 'core/register_team.html', {'hackathon': hackathon})


@login_required
def profile(request):
    return render(request, 'core/profile.html')